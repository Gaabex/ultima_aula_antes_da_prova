//Importa os modelos
const express = require('express');
const req = require('express/lib/request');

//Invocando o método Router() do Express
const router = express.Router();



//Criando as rotas
router.get('/',(req,res) => {

//let notaA1 = parseFloat(req.query.na1)
//let notaA2 = parseFloat(req.query.na2)
//let media = (notaA1+notaA2)/2

const notaA1 = parseFloat(req.query.a1);
const notaA2 = parseFloat(req.query.a2);
const media = (notaA1+notaA2)/2

let resAprov = "Reprovado"

if (media >= 6){
    resAprov = "Aprovado"
}

const objRaiz = {
    'resultado':resAprov,
    'notaA1': notaA1,
    'notaA2': notaA2,
    'media': media
    //'nome' : req.query.nome,
    //'idade' : req.query.idade,
    //'altura': req.query.altura,
    //'notaA1': notaA1,
    //'notaA2': notaA2,
    //'media' : media
 };


res.render('home', objRaiz)});


router.get('/contatos',(req,res) => {
    res.render('contatos');
});

//Exportação dos elementos
module.exports = router;
  