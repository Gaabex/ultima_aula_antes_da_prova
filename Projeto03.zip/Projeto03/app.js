//importação dos modulos e libs
const express = require("express");
const mustache = require("mustache-express");
const router = require("./router/index")

//configurações basicas do app
const app = express();
app.use('/', router);
app.use(express.json());

//config do template
app.engine('mst', mustache());
app.set('view engine', 'mst');
app.set('views', __dirname+ '/views');


//exportação do app
module.exports = app;       